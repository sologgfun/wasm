# test-node

## 用法

> node -r esm index.js