/* tslint:disable */
/* eslint-disable */
/**
* @param {string} str
* @returns {string}
*/
export function digest(str: string): string;
