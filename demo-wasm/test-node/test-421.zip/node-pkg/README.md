# demo-wasm
> wasm的md5加密demo，源码和测试代码均在本文件夹

## test-html
> 浏览器端的测试

## test-node
> node端的测试